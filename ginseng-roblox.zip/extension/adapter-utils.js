/**
 * Shared helpers for site adapters. Nothing site-specific lives here - just
 * the bits every adapter needs and that are easy to get subtly wrong
 * (native value setting, retrying a submit, finding a labeled code block).
 * Load this before any sites/*.js file.
 */

window.__ginsengUtils = {
  /**
   * Sets a value on a <textarea>/<input> OR a contenteditable element the
   * way a real user typing would, so React/Vue-controlled composers
   * actually notice. Plain `.value = x` is silently ignored by a lot of
   * these frameworks because they hook the native setter.
   */
  setNativeValue(el, text) {
    const tag = el.tagName;
    if (tag === "TEXTAREA" || tag === "INPUT") {
      const proto = tag === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (nativeSetter) nativeSetter.call(el, text);
      else el.value = text;
      el.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      // contenteditable div - likely a rich-text editor (Lexical, Slate,
      // ProseMirror, Draft.js) that manages its own internal state and
      // will silently discard a direct textContent write on its next
      // render. These editors are all built to handle paste through their
      // normal input pipeline, so simulating a paste event is the
      // reliable way in.
      el.focus();
      try {
        document.execCommand("selectAll", false, null);
        document.execCommand("delete", false, null);
      } catch (e) {
        /* best-effort clear; harmless if unsupported */
      }
      const dataTransfer = new DataTransfer();
      dataTransfer.setData("text/plain", text);
      const pasteEvent = new ClipboardEvent("paste", {
        clipboardData: dataTransfer,
        bubbles: true,
        cancelable: true,
      });
      el.dispatchEvent(pasteEvent);
    }
  },

  /**
   * Polls for the send button to become enabled and clicks it; if it never
   * does, falls back to a synthetic Enter keypress. Retries rather than
   * firing once, since composers often take a tick (or are briefly locked
   * while a previous response finishes) before they'll accept a submit.
   */
  retrySubmit({ getButton, isDisabled, input, maxAttempts = 12, intervalMs = 300 }) {
    const attempt = (attemptsLeft) => {
      const btn = getButton();
      if (btn && !isDisabled(btn)) {
        btn.click();
        return;
      }
      if (attemptsLeft <= 0) {
        const opts = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
        input.dispatchEvent(new KeyboardEvent("keydown", opts));
        input.dispatchEvent(new KeyboardEvent("keyup", opts));
        return;
      }
      setTimeout(() => attempt(attemptsLeft - 1), intervalMs);
    };
    setTimeout(() => attempt(maxAttempts), 100);
  },

  /**
   * Generic "find a rendered code block whose banner/label matches `label`,
   * return the code text" search. Works by looking for a leaf element whose
   * own text is exactly `label` (so we don't match a paragraph that merely
   * mentions the word), then searching nearby ancestors for a <pre>/<code>.
   * This is a reasonable default for most markdown renderers, but isn't
   * guaranteed - if a site's structure is weird, write a dedicated
   * findToolBlock for it instead of relying on this.
   */
  findFencedBlockByLabel(containerEl, label) {
    const all = containerEl.querySelectorAll("*");
    for (const el of all) {
      if (el.children.length === 0 && el.textContent.trim() === label) {
        let ancestor = el;
        // 10 levels gives real-world headroom - Kimi's actual structure
        // (label -> header-content -> header -> sticky-header ->
        // sticky-rail -> sticky-release -> segment-code, where the <pre>
        // sits as a sibling under segment-code) needed 7. A generic search
        // like this can't know a site's exact depth in advance, so err
        // wide rather than re-hunting this same off-by-one per site.
        for (let i = 0; i < 10 && ancestor; i++) {
          const codeEl = ancestor.querySelector && ancestor.querySelector("pre, code");
          if (codeEl) return codeEl.textContent.trim();
          ancestor = ancestor.parentElement;
        }
      }
    }
    return null;
  },
};
