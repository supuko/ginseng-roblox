/**
 * Ginseng content script - the generic agent loop.
 * All DOM knowledge lives in window.__ginsengAdapter (see sites/*.js).
 * This file only knows about: the WebSocket protocol to the Bridge, and the
 * ```ginseng-tool fenced-block convention for tool calls.
 */

(() => {
  const adapter = window.__ginsengAdapter;
  if (!adapter) {
    console.warn("[Ginseng] No site adapter loaded for this page.");
    return;
  }

  const BRIDGE_URL = "ws://127.0.0.1:8765";
  const TOOL_BLOCK_RE = /```ginseng-tool\s*([\s\S]*?)```/;

  // Tools that get a confirmation prompt before running, since they can
  // change or destroy things in the project with no other review step.
  // execute_luau (or similarly-named "run arbitrary code" tools) can do
  // literally anything, so it's always gated; anything whose name suggests
  // deletion/removal is gated too, regardless of which MCP server it's on.
  const SENSITIVE_TOOL_PATTERNS = [/^execute_luau$/i, /(delete|remove|destroy)/i];

  function isSensitiveTool(name) {
    return SENSITIVE_TOOL_PATTERNS.some((re) => re.test(name));
  }

  let ws = null;
  let sessionActive = false;
  let availableTools = [];
  const pendingRequests = new Map(); // id -> {resolve, reject}
  let reqCounter = 0;
  // tool name -> approved (bool). Cleared every time a new session starts,
  // since "remember for the rest of this session" is scoped to the session.
  let rememberedDecisions = new Map();

  // ---------- Bridge connection ----------

  function connectBridge() {
    ws = new WebSocket(BRIDGE_URL);

    ws.addEventListener("open", () => {
      setStatus(true, "Bridge connected");
      ws.send(JSON.stringify({ type: "list_tools", id: nextId() }));
    });

    ws.addEventListener("close", () => {
      setStatus(false, "Bridge offline - is bridge.py running?");
    });

    ws.addEventListener("error", () => {
      setStatus(false, "Bridge offline - is bridge.py running?");
    });

    ws.addEventListener("message", (event) => {
      const msg = JSON.parse(event.data);
      if (msg.type === "tools") {
        availableTools = msg.tools || [];
        updateToolCount(availableTools.length);
      } else if (msg.type === "result") {
        const pending = pendingRequests.get(msg.id);
        if (pending) {
          pendingRequests.delete(msg.id);
          if (msg.ok) pending.resolve(msg.result);
          else pending.reject(new Error(msg.error));
        }
      } else if (msg.type === "status") {
        setStatus(msg.studio_connected, msg.studio_connected ? "Studio connected" : "Studio not connected");
      }
    });
  }

  function nextId() {
    reqCounter += 1;
    return `req_${reqCounter}`;
  }

  function callTool(toolName, args) {
    return new Promise((resolve, reject) => {
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        reject(new Error("Bridge not connected"));
        return;
      }
      const id = nextId();
      pendingRequests.set(id, { resolve, reject });
      ws.send(JSON.stringify({ type: "call_tool", id, tool: toolName, args }));
    });
  }

  // ---------- System prompt (tool instructions) ----------

  function buildToolInstructions() {
    const toolList = availableTools
      .map((t) => {
        const schema = t.input_schema ? JSON.stringify(t.input_schema) : "{}";
        return `- ${t.name} (${t.server}): ${t.description || "no description"}\n  args schema: ${schema}`;
      })
      .join("\n");

    return [
      "You are now connected to Roblox Studio through Ginseng, a local MCP bridge.",
      "You have these tools available (each with its exact argument schema):",
      toolList || "(no tools reported yet - ask the user to check the Bridge window)",
      "",
      "IMPORTANT: when a specific structured tool exists for what you're trying to do (e.g. creating an",
      "instance, setting a property, inserting a GUI element), use that tool directly instead of writing",
      "Luau code to do it via a generic code-execution tool. Structured tools are safer, more predictable,",
      "and easier for the user to review than arbitrary scripts. Only fall back to a code-execution tool",
      "for logic that genuinely has no matching structured tool - e.g. custom algorithms, multi-step",
      "procedural generation, or anything conditional that a single structured call can't express.",
      "",
      "To use a tool, respond with ONLY a fenced code block in exactly this format, and nothing else in that message:",
      "```ginseng-tool",
      '{"tool": "<tool_name>", "args": { ... }}',
      "```",
      "After you send that, wait - the tool result will be sent to you as the next message.",
      "Only use this format when you actually need to call a tool. For normal conversation, reply normally.",
    ].join("\n");
  }

  // ---------- Watching for assistant messages ----------

  function startObserving() {
    const container = adapter.getMessagesContainer();
    const debounceTimers = new WeakMap(); // el -> timeout id
    // el -> last text content we actually checked. Using content as the key
    // (not just "have we seen this element before") matters because a lot
    // of these chat UIs virtualize their message list and recycle the same
    // DOM element to render different messages over time - we saw direct
    // evidence of this in DeepSeek's markup (data-virtual-list-item-key).
    // If we track "already handled" purely by element identity, a recycled
    // element showing a brand-new message gets silently skipped forever,
    // since we'd already marked that element as done for an earlier
    // message. Comparing content means a truly-unchanged message is still
    // skipped (no duplicate tool execution), but a reused element with new
    // content is correctly treated as new.
    const lastSignature = new WeakMap();
    // Guards against a different failure mode than the one above: some of
    // these turns keep appending content to the same message AFTER the
    // tool-call block already rendered (Kimi's own multi-step "Execute
    // Python code" trace does this). That would make the content
    // signature check above think the message "changed" again and re-scan
    // it - finding the same tool call JSON a second time. Tracking exact
    // tool-call text we've already dispatched stops that from executing
    // twice.
    const processedToolCalls = new Set();
    const QUIET_MS = 800; // no DOM changes to this message for this long = treat as done streaming

    const checkMessage = (el) => {
      if (!sessionActive) return;

      const signature = adapter.extractText(el);
      if (lastSignature.get(el) === signature) return; // unchanged since last check - already handled
      lastSignature.set(el, signature);

      const toolJson = adapter.findToolBlock
        ? adapter.findToolBlock(el)
        : (signature.match(TOOL_BLOCK_RE) || [])[1];
      if (!toolJson) return; // no tool call in this message, nothing to do

      const trimmed = toolJson.trim();
      if (processedToolCalls.has(trimmed)) return; // already dispatched this exact call
      processedToolCalls.add(trimmed);

      handleToolCall(trimmed);
    };

    const observer = new MutationObserver(() => {
      if (!sessionActive) return;

      const messages = adapter.getAssistantMessageEls();
      const last = messages[messages.length - 1];
      if (!last) return;

      // Every time this message's DOM changes (new streamed tokens, or a
      // recycled element being repurposed for a new message), push the
      // check back out. Once QUIET_MS passes with no further changes, we
      // treat it as finished and safe to parse.
      clearTimeout(debounceTimers.get(last));
      debounceTimers.set(
        last,
        setTimeout(() => checkMessage(last), QUIET_MS)
      );
    });

    observer.observe(container, { childList: true, subtree: true, characterData: true });
  }

  // ---------- Confirmation modal for sensitive tool calls ----------

  function showConfirmModal(call) {
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      overlay.id = "ginseng-confirm-overlay";

      const panel = document.createElement("div");
      panel.id = "ginseng-confirm-panel";

      const title = document.createElement("div");
      title.className = "ginseng-confirm-title";
      title.textContent = `Ginseng wants to run "${call.tool}"`;

      const subtitle = document.createElement("div");
      subtitle.className = "ginseng-confirm-subtitle";
      subtitle.textContent = "This can change your project. Review the arguments before approving.";

      const argsPre = document.createElement("pre");
      argsPre.className = "ginseng-confirm-args";
      argsPre.textContent = JSON.stringify(call.args || {}, null, 2);

      const rememberLabel = document.createElement("label");
      rememberLabel.className = "ginseng-confirm-remember";
      const rememberCheckbox = document.createElement("input");
      rememberCheckbox.type = "checkbox";
      rememberLabel.appendChild(rememberCheckbox);
      rememberLabel.appendChild(
        document.createTextNode(` Remember this choice for "${call.tool}" for the rest of this session`)
      );

      const btnRow = document.createElement("div");
      btnRow.className = "ginseng-confirm-buttons";
      const denyBtn = document.createElement("button");
      denyBtn.textContent = "Deny";
      denyBtn.className = "ginseng-confirm-deny";
      const approveBtn = document.createElement("button");
      approveBtn.textContent = "Approve";
      approveBtn.className = "ginseng-confirm-approve";

      const cleanup = (approved) => {
        overlay.remove();
        resolve({ approved, remember: rememberCheckbox.checked });
      };
      denyBtn.addEventListener("click", () => cleanup(false));
      approveBtn.addEventListener("click", () => cleanup(true));

      btnRow.appendChild(denyBtn);
      btnRow.appendChild(approveBtn);

      panel.appendChild(title);
      panel.appendChild(subtitle);
      panel.appendChild(argsPre);
      panel.appendChild(rememberLabel);
      panel.appendChild(btnRow);
      overlay.appendChild(panel);
      document.documentElement.appendChild(overlay);
    });
  }

  async function handleToolCall(jsonText) {
    let call;
    try {
      call = JSON.parse(jsonText);
    } catch (e) {
      adapter.sendMessage(
        "```ginseng-tool-error\nYour last message wasn't valid JSON in the ginseng-tool block. Please retry.\n```"
      );
      return;
    }

    if (isSensitiveTool(call.tool)) {
      let approved = rememberedDecisions.get(call.tool);
      if (approved === undefined) {
        const decision = await showConfirmModal(call);
        approved = decision.approved;
        if (decision.remember) rememberedDecisions.set(call.tool, approved);
      }
      if (!approved) {
        adapter.sendMessage(
          "Tool result:\n```ginseng-result\n" +
            JSON.stringify({ is_error: true, content: ["The user declined to run this tool call for safety review."] }, null, 2) +
            "\n```"
        );
        return;
      }
    }

    try {
      const result = await callTool(call.tool, call.args || {});
      adapter.sendMessage(
        "Tool result:\n```ginseng-result\n" + JSON.stringify(result, null, 2) + "\n```"
      );
    } catch (err) {
      adapter.sendMessage(
        "```ginseng-tool-error\n" + String(err.message || err) + "\n```"
      );
    }
  }

  // ---------- Floating bar UI ----------

  function buildBar() {
    const bar = document.createElement("div");
    bar.id = "ginseng-bar";
    bar.innerHTML = `
      <span class="ginseng-dot" id="ginseng-dot"></span>
      <span id="ginseng-status">Connecting...</span>
      <span id="ginseng-tools"></span>
      <button id="ginseng-toggle">Start session</button>
    `;
    document.documentElement.appendChild(bar);

    document.getElementById("ginseng-toggle").addEventListener("click", () => {
      sessionActive = !sessionActive;
      const btn = document.getElementById("ginseng-toggle");
      btn.textContent = sessionActive ? "Stop session" : "Start session";
      btn.classList.toggle("active", sessionActive);
      if (sessionActive) {
        rememberedDecisions = new Map();
        adapter.sendMessage(buildToolInstructions());
      }
    });
  }

  function setStatus(ok, label) {
    const dot = document.getElementById("ginseng-dot");
    const status = document.getElementById("ginseng-status");
    if (!dot || !status) return;
    dot.classList.toggle("ok", !!ok);
    dot.classList.toggle("bad", !ok);
    status.textContent = label;
  }

  function updateToolCount(n) {
    const el = document.getElementById("ginseng-tools");
    if (el) el.textContent = `- ${n} tools`;
  }

  // ---------- Init ----------

  function init() {
    buildBar();
    connectBridge();
    startObserving();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
