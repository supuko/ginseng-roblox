# Ginseng

A free, self-hosted AI agent for Roblox Studio. You bring your own free AI chat
(DeepSeek, etc); Ginseng lets it read/edit your Studio project.

Two pieces, both run entirely on your own machine:

```
chat.deepseek.com (browser tab)
   |  content script watches the page, types into the composer
   v
Ginseng extension  <--- WebSocket (ws://127.0.0.1:8765) --->  Ginseng Bridge (bridge.py)
                                                                    |  MCP
                                                                    v
                                                          Roblox Studio's MCP server
```

Nothing leaves your machine except the normal chat traffic to whichever AI
site you're using.

## 1. Set up the Bridge

```bash
cd bridge
pip install -r requirements.txt
```

Open Roblox Studio, load a place, and enable its built-in MCP server (in the
Assistant/AI settings panel - look for "Enable MCP Server"). Check what
host/port it listens on and update `bridge/config.json` if it differs from
the default (`http://127.0.0.1:13469/mcp`).

Then run:

```bash
python bridge.py
```

You should see `Connected to MCP server 'studio' at ...` in the terminal. Keep
this window open while you work - it's your local server.

## 2. Load the extension

1. Go to `chrome://extensions` (or `edge://extensions`)
2. Enable Developer mode
3. Click "Load unpacked", select the `extension/` folder

## 3. Use it

1. Open `chat.deepseek.com`, start a new chat
2. You'll see a small Ginseng bar in the top-right corner. It should show a
   green dot once it connects to the Bridge.
3. Click "Start session" - this sends the AI its tool instructions
4. Just type what you want built, normally, in the chat

## How the agent loop works

DeepSeek's web chat has no real tool-calling API, so Ginseng fakes one with a
convention: the AI is instructed to answer with a fenced code block like

```ginseng-tool
{"tool": "edit_script", "args": {"path": "...", "code": "..."}}
```

whenever it wants to use a tool. The content script watches the page for new
assistant messages, looks for that block, sends it to the Bridge, gets a
result back from Roblox Studio via MCP, and types the result back into the
chat as the next message so the AI can keep going.

## Project layout

```
bridge/
  bridge.py        - WebSocket server + MCP client(s). Site-agnostic.
  config.json       - ports, Studio MCP URL, optional addon servers
  requirements.txt

extension/
  manifest.json
  content.js        - generic agent loop (WebSocket protocol, tool-block parsing)
  sites/
    deepseek.js      - ALL the DOM selectors for chat.deepseek.com live here
  bar.css
```

## Adding another chat site (Gemini, Kimi, etc)

1. Copy `extension/sites/deepseek.js` to e.g. `extension/sites/gemini.js`
2. Update the selectors by inspecting that site's DOM (input box, send
   button, assistant message bubbles, "is generating" indicator)
3. Add the new file + host permission + content_scripts match pattern to
   `manifest.json`

`content.js` and `bridge.py` need no changes - all the site-specific fragility
is isolated to the adapter files, which is also where you'll need to make
fixes when a site redesigns its UI.

## Adding an addon MCP server (Blender, Sketchfab, ...)

Add an entry to `addon_mcp_servers` in `bridge/config.json`:

```json
"addon_mcp_servers": [
  {"name": "blender", "url": "http://127.0.0.1:PORT/mcp"}
]
```

The Bridge tries Studio first for every tool call, then falls back to
connected addons - so Roblox Studio stays the primary connection.

## Known rough edges (expect to fix these as you go)

- Chat site DOM selectors in `sites/*.js` will break when that site ships a
  redesign - this is the main ongoing maintenance cost of this whole approach
- React/Vue-controlled inputs sometimes ignore a plain `.value =` assignment;
  `deepseek.js` uses the native property setter + a dispatched `input` event
  to work around this, but each site can behave differently
- Confirm the exact URL Roblox Studio's MCP server listens on in your version
  of Studio - it's configurable in `bridge/config.json`
