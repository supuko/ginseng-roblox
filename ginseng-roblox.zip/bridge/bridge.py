"""
Ginseng Bridge
==============
Runs locally on your PC. Sits between:

  Browser extension (content script on chat.deepseek.com etc)
        <--- WebSocket, ws://127.0.0.1:8765 --->
  Bridge (this file)
        <--- MCP protocol --->
  Roblox Studio's built-in MCP server (+ optional addon MCP servers)

Start it with:  python bridge.py
Stop it with:   Ctrl+C

Protocol between extension and bridge (JSON messages over the WebSocket):

  Extension -> Bridge
    {"type": "list_tools", "id": "<req-id>"}
    {"type": "call_tool", "id": "<req-id>", "tool": "<tool_name>", "args": {...}}

  Bridge -> Extension
    {"type": "tools", "id": "<req-id>", "tools": [ {name, description, input_schema}, ... ]}
    {"type": "result", "id": "<req-id>", "ok": true, "result": <anything>}
    {"type": "result", "id": "<req-id>", "ok": false, "error": "<message>"}
    {"type": "status", "studio_connected": bool, "addons_connected": [names]}
"""

import asyncio
import json
import logging
import sys
from contextlib import AsyncExitStack
from pathlib import Path

import websockets

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    from mcp.client.streamable_http import streamablehttp_client
except ImportError:
    print(
        "Missing the 'mcp' package. Install dependencies first:\n"
        "  pip install -r requirements.txt",
        file=sys.stderr,
    )
    sys.exit(1)

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("ginseng-bridge")

CONFIG_PATH = Path(__file__).parent / "config.json"


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


class MCPServerLink:
    """
    One live connection to a single MCP server (Studio, or an addon).

    Supports two transports, picked via config:
      - "stdio": we spawn a local process (e.g. rbx-studio-mcp.exe --stdio)
        and talk MCP over its stdin/stdout. This is what Roblox Studio's
        official built-in MCP server uses.
      - "streamable_http": we connect to a URL. Used for addon MCP servers
        that expose an HTTP endpoint instead.

    All context managers are entered into a single AsyncExitStack owned by
    the bridge, and everything is opened/closed from the same asyncio task
    (see GinsengBridge.connect_all / shutdown) - mixing tasks is what caused
    the "cancel scope in a different task" errors from anyio/httpx before.
    """

    def __init__(self, name: str, server_config: dict, exit_stack: AsyncExitStack):
        self.name = name
        self.config = server_config
        self.transport = server_config.get("transport", "stdio")
        self._exit_stack = exit_stack
        self.session: ClientSession | None = None
        self.connected = False

    async def connect(self):
        try:
            if self.transport == "stdio":
                params = StdioServerParameters(
                    command=self.config["command"],
                    args=self.config.get("args", []),
                    env=self.config.get("env"),
                )
                read_stream, write_stream = await self._exit_stack.enter_async_context(
                    stdio_client(params)
                )
            elif self.transport == "streamable_http":
                read_stream, write_stream, _ = await self._exit_stack.enter_async_context(
                    streamablehttp_client(self.config["url"])
                )
            else:
                raise ValueError(f"Unknown transport '{self.transport}' for '{self.name}'")

            self.session = await self._exit_stack.enter_async_context(
                ClientSession(read_stream, write_stream)
            )
            await self.session.initialize()
            self.connected = True
            log.info(f"Connected to MCP server '{self.name}' ({self.transport})")
        except Exception as e:
            self.connected = False
            log.warning(f"Could not connect to '{self.name}': {e}")

    async def list_tools(self):
        if not self.connected:
            return []
        result = await self.session.list_tools()
        return [
            {"name": t.name, "description": t.description, "input_schema": t.inputSchema}
            for t in result.tools
        ]

    async def call_tool(self, tool_name: str, args: dict):
        if not self.connected:
            raise RuntimeError(f"'{self.name}' is not connected")
        result = await self.session.call_tool(tool_name, arguments=args)
        # Flatten MCP content blocks into plain text/JSON for the extension.
        out = []
        for block in result.content:
            if hasattr(block, "text"):
                out.append(block.text)
            else:
                out.append(str(block))
        return {"is_error": bool(getattr(result, "isError", False)), "content": out}


class GinsengBridge:
    def __init__(self, config: dict, exit_stack: AsyncExitStack):
        self.config = config
        self.exit_stack = exit_stack
        self.studio = MCPServerLink("studio", config["studio_mcp_server"], exit_stack)
        self.addons: dict[str, MCPServerLink] = {
            a["name"]: MCPServerLink(a["name"], a, exit_stack)
            for a in config.get("addon_mcp_servers", [])
        }

    async def connect_all(self):
        await self.studio.connect()
        for link in self.addons.values():
            await link.connect()

    def all_links(self):
        return [self.studio] + list(self.addons.values())

    async def list_all_tools(self):
        tools = []
        for link in self.all_links():
            for t in await link.list_tools():
                t = dict(t)
                t["server"] = link.name
                tools.append(t)
        return tools

    async def route_call(self, tool_name: str, args: dict):
        """Try Studio first (it's the primary, always-on connection), then addons."""
        errors = []
        for link in self.all_links():
            if not link.connected:
                continue
            try:
                names = {t["name"] for t in await link.list_tools()}
            except Exception as e:
                errors.append(f"{link.name}: {e}")
                continue
            if tool_name in names:
                return await link.call_tool(tool_name, args)
        raise RuntimeError(
            f"Tool '{tool_name}' not found on any connected server. "
            f"(errors: {errors})" if errors else f"Tool '{tool_name}' not found on any connected server."
        )

    def status(self):
        return {
            "studio_connected": self.studio.connected,
            "addons_connected": [n for n, l in self.addons.items() if l.connected],
        }


async def handle_client(websocket, bridge: GinsengBridge):
    log.info("Extension connected.")
    await websocket.send(json.dumps({"type": "status", **bridge.status()}))

    async for raw in websocket:
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            continue

        req_id = msg.get("id")
        mtype = msg.get("type")

        try:
            if mtype == "list_tools":
                tools = await bridge.list_all_tools()
                await websocket.send(json.dumps({"type": "tools", "id": req_id, "tools": tools}))

            elif mtype == "call_tool":
                tool = msg.get("tool")
                args = msg.get("args", {})
                log.info(f"Tool call: {tool} {args}")
                result = await bridge.route_call(tool, args)
                await websocket.send(json.dumps({"type": "result", "id": req_id, "ok": True, "result": result}))

            elif mtype == "status":
                await websocket.send(json.dumps({"type": "status", **bridge.status()}))

            else:
                await websocket.send(json.dumps({"type": "result", "id": req_id, "ok": False, "error": f"Unknown message type '{mtype}'"}))

        except Exception as e:
            log.error(f"Error handling '{mtype}': {e}")
            await websocket.send(json.dumps({"type": "result", "id": req_id, "ok": False, "error": str(e)}))

    log.info("Extension disconnected.")


async def main():
    config = load_config()

    async with AsyncExitStack() as exit_stack:
        bridge = GinsengBridge(config, exit_stack)
        await bridge.connect_all()

        host = config["bridge_ws_host"]
        port = config["bridge_ws_port"]

        async def handler(websocket):
            await handle_client(websocket, bridge)

        log.info(f"Ginseng Bridge listening on ws://{host}:{port}")
        log.info("Waiting for the browser extension to connect...")
        async with websockets.serve(handler, host, port):
            await asyncio.Future()  # run forever


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nGinseng Bridge stopped.")
