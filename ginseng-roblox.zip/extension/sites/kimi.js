/**
 * Site adapter: kimi.com
 *
 * Input/send-button selectors AND findToolBlock() confirmed against the
 * live DOM (2026-07-25). Kimi's code-block label sits several levels above
 * the actual <pre> (label -> header-content -> header -> sticky-header ->
 * sticky-rail -> sticky-release -> segment-code, with the code as a
 * sibling under segment-code) - the generic findFencedBlockByLabel() in
 * adapter-utils.js handles this fine now that its search depth was
 * widened; no dedicated version needed here.
 */

window.__ginsengAdapter = {
  siteName: "kimi",

  // Confirmed against the live DOM on 2026-07-25.
  // Input is a Lexical rich-text editor (data-lexical-editor="true"), NOT a
  // plain textarea - see the paste-event handling in adapter-utils.js.
  INPUT_SELECTOR: '.chat-input-editor[contenteditable="true"]',
  // Send is a plain div, not a button; toggles a "disabled" class (no
  // real disabled attribute) when the editor is empty.
  SEND_BUTTON_SELECTOR: ".send-button-container",
  // One full assistant turn (thinking block + final answer + action bar).
  // Kimi's classes look like semantic Vue component names rather than
  // per-build hashes, so these should be relatively stable - but unverified
  // against a redesign.
  ASSISTANT_MESSAGE_SELECTOR: ".segment-content",
  MESSAGES_CONTAINER_SELECTOR: "main",

  // If Kimi renders a code block with a language/filename banner the way
  // DeepSeek does, put that exact label text here (matches the fenced
  // block convention content.js sends: ```ginseng-tool).
  TOOL_BLOCK_LABEL: "ginseng-tool",

  getInputEl() {
    return document.querySelector(this.INPUT_SELECTOR);
  },

  getSendButtonEl() {
    return document.querySelector(this.SEND_BUTTON_SELECTOR);
  },

  isSendButtonDisabled(el) {
    if (!el) return true;
    return el.classList.contains("disabled");
  },

  getMessagesContainer() {
    return document.querySelector(this.MESSAGES_CONTAINER_SELECTOR) || document.body;
  },

  getAssistantMessageEls() {
    return Array.from(document.querySelectorAll(this.ASSISTANT_MESSAGE_SELECTOR));
  },

  extractText(el) {
    return el.innerText || el.textContent || "";
  },

  findToolBlock(messageEl) {
    // Generic fallback: look for a leaf element whose text exactly matches
    // the label, then hunt nearby for a <pre>/<code>. Swap this out for a
    // hand-written version (like deepseek.js's) once you've seen the real
    // markup - the generic version is a reasonable first try, not a
    // guarantee.
    return window.__ginsengUtils.findFencedBlockByLabel(messageEl, this.TOOL_BLOCK_LABEL);
  },

  sendMessage(text) {
    const input = this.getInputEl();
    if (!input) {
      console.warn("[Ginseng] Could not find the input box.");
      return false;
    }

    window.__ginsengUtils.setNativeValue(input, text);
    window.__ginsengUtils.retrySubmit({
      getButton: () => this.getSendButtonEl(),
      isDisabled: (btn) => this.isSendButtonDisabled(btn),
      input,
    });

    return true;
  },
};
