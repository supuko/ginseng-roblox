/**
 * Site adapter: chat.deepseek.com
 *
 * This is the ONLY file that should contain DOM selectors. Every other file
 * (content.js, bridge.py) is site-agnostic. When DeepSeek changes their UI
 * and things break, this is the file to fix - open devtools, inspect the
 * input box / send button / message bubbles, and update the selectors below.
 *
 * NOTE: the selectors here are placeholders based on common patterns for
 * this type of chat UI. Confirm/adjust them against the live site before
 * relying on this - right-click the input box -> Inspect, and update
 * INPUT_SELECTOR etc to match what you actually see.
 */

window.__ginsengAdapter = {
  siteName: "deepseek",

  // Confirmed against the live DOM on 2026-07-25. DeepSeek's send button is
  // a <div role="button">, not a real <button>, and it carries the
  // "ds-button--disabled" class (not the disabled attribute) when there's
  // nothing to send - so we check the class, not .disabled.
  INPUT_SELECTOR: 'textarea[placeholder="Message DeepSeek"]',
  SEND_BUTTON_SELECTOR: 'div[role="button"].ds-button--primary.ds-button--circle',
  // Each assistant reply's text lives in this inner div; its ancestor
  // message bubble is what we treat as "one message" for dedup purposes.
  ASSISTANT_MESSAGE_SELECTOR: ".ds-markdown.ds-assistant-message-main-content",
  MESSAGES_CONTAINER_SELECTOR: "main",

  getInputEl() {
    return document.querySelector(this.INPUT_SELECTOR);
  },

  getSendButtonEl() {
    return document.querySelector(this.SEND_BUTTON_SELECTOR);
  },

  isSendButtonDisabled(el) {
    // DeepSeek's send button is a <div role="button">, so there's no real
    // .disabled property - it toggles a class instead.
    return el ? el.classList.contains("ds-button--disabled") : true;
  },

  getMessagesContainer() {
    return document.querySelector(this.MESSAGES_CONTAINER_SELECTOR) || document.body;
  },

  getAssistantMessageEls() {
    return Array.from(document.querySelectorAll(this.ASSISTANT_MESSAGE_SELECTOR));
  },

  extractText(el) {
    return el.innerText || el.textContent || "";
  },

  /**
   * DeepSeek renders fenced code blocks (```ginseng-tool ... ```) into a
   * .md-code-block div - by the time we read the DOM, the backticks are
   * long gone. Structure (confirmed against the live page):
   *
   *   <div class="md-code-block ...">
   *     <div class="md-code-block-banner-wrap">...text incl "ginseng-tool"...</div>
   *     <pre><span>{"tool": "...", "args": {...}}</span></pre>
   *   </div>
   *
   * We deliberately match on the generic "md-code-block" class rather than
   * the hashed per-build classes (e.g. "d813de27") sitting alongside it -
   * those look like CSS-module hashes and are far more likely to change on
   * the next DeepSeek deploy than the semantic "md-code-block" name is.
   *
   * Returns the raw JSON text of the tool call, or null if this message
   * doesn't contain one.
   */
  findToolBlock(messageEl) {
    const blocks = messageEl.querySelectorAll(".md-code-block");
    for (const block of blocks) {
      const banner = block.querySelector(".md-code-block-banner-wrap");
      const label = banner ? banner.textContent.trim() : "";
      if (label.startsWith("ginseng-tool")) {
        const pre = block.querySelector("pre");
        const text = pre ? pre.textContent.trim() : "";
        return text || null;
      }
    }
    return null;
  },

  /**
   * Types text into the composer and submits it, the way a real user would.
   * Many chat UIs are built with React/Vue and ignore a plain `.value = x`
   * assignment because their internal state doesn't see it. Dispatching a
   * native input event (via the native setter) is what makes it "count".
   */
  sendMessage(text) {
    const input = this.getInputEl();
    if (!input) {
      console.warn("[Ginseng] Could not find the input box.");
      return false;
    }

    window.__ginsengUtils.setNativeValue(input, text);
    window.__ginsengUtils.retrySubmit({
      getButton: () => this.getSendButtonEl(),
      isDisabled: (btn) => this.isSendButtonDisabled(btn),
      input,
    });

    return true;
  },

  /**
   * Is the assistant still generating a response? Used so we don't try to
   * parse a message while it's still streaming in.
   */
  isGenerating() {
    const stopBtn = document.querySelector('[aria-label*="stop" i], [class*="stop"]');
    return !!stopBtn;
  },
};
